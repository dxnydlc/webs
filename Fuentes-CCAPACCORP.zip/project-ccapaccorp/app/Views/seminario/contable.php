
<?= $this->extend('layouts/principal') ?>



<!-- ************************************************** -->
<?= $this->section('titulo') ?>
Inicio
<?= $this->endSection() ?>
<!-- ************************************************** -->





<!-- ************************************************** -->
<?= $this->section('header') ?>
CcapaCcorp
<?= $this->endSection() ?>
<!-- ************************************************** -->


<!-- ************************************************** -->
<?= $this->section('header-class') ?>
main-header-two
<?= $this->endSection() ?>
<!-- ************************************************** -->






<!-- ************************************************** -->
<?= $this->section('content') ?>

<!-- ============================================================== -->


<div class="stricky-header stricked-menu main-menu main-header-two">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->

<div class="row" style="margin-top: 50px;" >
    <div class="col-lg-3"></div>
    <div class="col-lg-6">
        <img src="/2024/contruccion.png" class="img-fluid" alt="">
    </div>
    <div class="col-lg-3"></div>
</div>
<!-- /.page-header -->



<!-- ============================================================== -->

<?= $this->endSection() ?>
<!-- ************************************************** -->

